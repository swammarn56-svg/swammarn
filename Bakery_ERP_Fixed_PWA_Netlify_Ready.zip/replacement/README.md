# Bakery ERP replacement source

This folder contains the repaired Bakery ERP static app and its installable PWA files.

## Included files

- `index.html`, `app.js`, `style.css` — application source
- `manifest.webmanifest`, `sw.js`, and `icons/` — PWA install metadata, app-shell caching, and icons
- `firestore.rules` — deploy these rules to the same Firebase project before production use

Serve the folder over HTTPS (or `localhost`) to enable service-worker registration and PWA installation. Firebase authentication and cloud data still require a network connection; local browser data remains available as a fallback.

The first-login Firestore rule allows an authenticated user to read only their own missing profile so the client can create the restricted staff profile. Other user/profile access remains protected.

The legacy app stores business state in `appData/main`; the supplied Rules protect access using authenticated active user profiles and protect user role escalation. Future hardening should split the monolithic state document by tenant/date/entity and add field-level validation.
